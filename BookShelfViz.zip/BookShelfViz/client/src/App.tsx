import { Canvas } from "@react-three/fiber";
import { Suspense, useState, useEffect } from "react";
import { OrbitControls, Environment, PerspectiveCamera } from "@react-three/drei";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "sonner";
import BooksList from "./components/BooksList";
import FilterBar from "./components/FilterBar";
import Lighting from "./components/Lighting";
import { BooksProvider } from "./lib/stores/useBooks";
import BookDetail from "./components/BookDetail";
import Bookshelf from "./components/Bookshelf";

function App() {
  const [selectedBook, setSelectedBook] = useState<number | null>(null);
  const [isMobile, setIsMobile] = useState(false);

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener("resize", checkMobile);
    
    return () => {
      window.removeEventListener("resize", checkMobile);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <BooksProvider>
        <div className="relative w-full h-screen bg-gradient-to-b from-blue-900 to-black">
          {/* Header */}
          <header className="absolute top-0 left-0 right-0 z-10 bg-gray-900/80 backdrop-blur-sm p-4 text-white">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl md:text-3xl font-bold">3D Book Collection</h1>
            </div>
          </header>

          {/* Filter Bar */}
          <div className="absolute top-16 left-0 right-0 z-10 bg-gray-800/70 backdrop-blur-sm">
            <FilterBar />
          </div>

          {/* 3D Canvas */}
          <Canvas shadows>
            <color attach="background" args={["#050816"]} />
            <fog attach="fog" args={["#070b2c", 10, 20]} />

            {/* Camera */}
            <PerspectiveCamera 
              makeDefault 
              position={isMobile ? [0, 3, 8] : [0, 2, 6]} 
              fov={50}
            />
            
            {/* Controls */}
            <OrbitControls 
              enablePan={false}
              minPolarAngle={Math.PI / 6}
              maxPolarAngle={Math.PI / 2}
              minDistance={4}
              maxDistance={10}
            />

            <Lighting />
            
            {/* Environment for reflections */}
            <Environment preset="city" />

            {/* Bookshelves */}
            <Suspense fallback={null}>
              {/* Main bookshelf */}
              <Bookshelf 
                position={[0, -1.5, 0]} 
                width={12} 
                height={3} 
                depth={1.5} 
              />
              
              {/* Side bookshelves */}
              <Bookshelf 
                position={[-7, -1.5, 0]} 
                rotation={[0, Math.PI / 6, 0]}
                width={8} 
                height={3} 
                depth={1.2} 
              />
              
              <Bookshelf 
                position={[7, -1.5, 0]} 
                rotation={[0, -Math.PI / 6, 0]}
                width={8} 
                height={3} 
                depth={1.2} 
              />
            </Suspense>

            {/* Book List */}
            <Suspense fallback={null}>
              <BooksList onSelectBook={setSelectedBook} />
            </Suspense>
          </Canvas>

          {/* Book Detail Modal */}
          {selectedBook !== null && (
            <BookDetail 
              bookId={selectedBook} 
              onClose={() => setSelectedBook(null)} 
            />
          )}

          {/* Toaster for notifications */}
          <Toaster position="bottom-right" />
        </div>
      </BooksProvider>
    </QueryClientProvider>
  );
}

export default App;
