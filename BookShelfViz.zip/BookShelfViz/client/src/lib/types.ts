export type BookSort = "title" | "author" | "recent";

export interface BookType {
  id: number;
  title: string;
  author: string;
  genre: string;
  description: string;
  pages: number;
  publishYear: number;
  language: string;
  isbn: string;
  favorite: boolean;
}
