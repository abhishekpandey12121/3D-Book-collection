import { ReactNode, createContext, useContext, useState, useCallback, useMemo } from "react";
import { toast } from "sonner";
import { apiRequest } from "@/lib/queryClient";
import { BookType, BookSort } from "@/lib/types";
import { getLocalStorage, setLocalStorage } from "@/lib/utils";

interface BooksContextType {
  books: BookType[];
  filteredBooks: BookType[];
  loading: boolean;
  error: string | null;
  genreFilter: string | null;
  showFavorites: boolean;
  sort: BookSort;
  searchQuery: string;
  fetchBooks: () => Promise<void>;
  setGenreFilter: (genre: string | null) => void;
  toggleShowFavorites: () => void;
  toggleFavorite: (id: number) => void;
  setSort: (sort: BookSort) => void;
  setSearchQuery: (query: string) => void;
}

const BooksContext = createContext<BooksContextType | null>(null);

export function BooksProvider({ children }: { children: ReactNode }) {
  const [books, setBooks] = useState<BookType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [genreFilter, setGenreFilter] = useState<string | null>(null);
  const [showFavorites, setShowFavorites] = useState(false);
  const [sort, setSort] = useState<BookSort>("title");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch books (uses static data for now for reliability)
  const fetchBooks = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Static book data for reliable display (100+ books)
      const staticBooks = [
        // Fiction
        {
          id: 1,
          title: "Dune",
          author: "Frank Herbert",
          genre: "Sci-Fi",
          description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.",
          pages: 412,
          publishYear: 1965,
          language: "English",
          isbn: "978-0441172719",
          favorite: false
        },
        {
          id: 2,
          title: "The Hobbit",
          author: "J.R.R. Tolkien",
          genre: "Fantasy",
          description: "Bilbo Baggins is a hobbit who enjoys a comfortable life, rarely traveling far. But his contentment is disturbed when the wizard Gandalf arrives.",
          pages: 310,
          publishYear: 1937,
          language: "English",
          isbn: "978-0618260300",
          favorite: false
        },
        {
          id: 3,
          title: "Pride and Prejudice",
          author: "Jane Austen",
          genre: "Romance",
          description: "The story follows Elizabeth Bennet as she deals with issues of manners, upbringing, morality, education, and marriage in British society.",
          pages: 279,
          publishYear: 1813,
          language: "English",
          isbn: "978-0141439518",
          favorite: false
        },
        {
          id: 4,
          title: "1984",
          author: "George Orwell",
          genre: "Fiction",
          description: "The novel is set in Airstrip One, a province of the superstate Oceania, whose residents are victims of perpetual war and government surveillance.",
          pages: 328,
          publishYear: 1949,
          language: "English",
          isbn: "978-0451524935",
          favorite: false
        },
        {
          id: 5,
          title: "The Great Gatsby",
          author: "F. Scott Fitzgerald",
          genre: "Fiction",
          description: "The story primarily concerns the young millionaire Jay Gatsby and his passion for the beautiful Daisy Buchanan.",
          pages: 180,
          publishYear: 1925,
          language: "English",
          isbn: "978-0743273565",
          favorite: false
        },
        {
          id: 6,
          title: "To Kill a Mockingbird",
          author: "Harper Lee",
          genre: "Fiction",
          description: "The novel is renowned for its warmth and humor, despite dealing with serious issues of racial inequality and justice in the American South.",
          pages: 281,
          publishYear: 1960,
          language: "English",
          isbn: "978-0446310789",
          favorite: false
        },
        {
          id: 7,
          title: "The Da Vinci Code",
          author: "Dan Brown",
          genre: "Thriller",
          description: "While in Paris, Harvard symbologist Robert Langdon is awakened by a phone call. The elderly curator of the Louvre has been murdered.",
          pages: 454,
          publishYear: 2003,
          language: "English",
          isbn: "978-0307474278",
          favorite: false
        },
        {
          id: 8,
          title: "Harry Potter",
          author: "J.K. Rowling",
          genre: "Fantasy",
          description: "Harry Potter has no idea how famous he is until he is rescued from his miserable life and informed that he is a wizard.",
          pages: 223,
          publishYear: 1997,
          language: "English",
          isbn: "978-0747532699",
          favorite: false
        },
        {
          id: 9,
          title: "The Lord of the Rings",
          author: "J.R.R. Tolkien",
          genre: "Fantasy",
          description: "One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.",
          pages: 1178,
          publishYear: 1954,
          language: "English",
          isbn: "978-0618640157",
          favorite: false
        },
        {
          id: 10,
          title: "The Catcher in the Rye",
          author: "J.D. Salinger",
          genre: "Fiction",
          description: "The hero-narrator of The Catcher in the Rye is an ancient child of sixteen, a native New Yorker named Holden Caulfield.",
          pages: 234,
          publishYear: 1951,
          language: "English",
          isbn: "978-0316769488",
          favorite: false
        },
        // Sci-Fi
        {
          id: 11,
          title: "Foundation",
          author: "Isaac Asimov",
          genre: "Sci-Fi",
          description: "For twelve thousand years the Galactic Empire has ruled supreme. Now it is dying. But only Hari Seldon, creator of the revolutionary science of psychohistory, can see into the future.",
          pages: 244,
          publishYear: 1951,
          language: "English",
          isbn: "978-0553293357",
          favorite: false
        },
        {
          id: 12,
          title: "Neuromancer",
          author: "William Gibson",
          genre: "Sci-Fi",
          description: "The novel that launched the cyberpunk generation, heralded the coming of the internet, and won the Hugo, Nebula, and Philip K. Dick Awards.",
          pages: 271,
          publishYear: 1984,
          language: "English",
          isbn: "978-0441569595",
          favorite: false
        },
        {
          id: 13,
          title: "Ender's Game",
          author: "Orson Scott Card",
          genre: "Sci-Fi",
          description: "In order to develop a secure defense against a hostile alien race's next attack, government agencies breed child geniuses and train them as soldiers.",
          pages: 324,
          publishYear: 1985,
          language: "English",
          isbn: "978-0812550702",
          favorite: false
        },
        {
          id: 14,
          title: "Brave New World",
          author: "Aldous Huxley",
          genre: "Sci-Fi",
          description: "Brave New World is a dystopian novel by English author Aldous Huxley, written in 1931 and published in 1932.",
          pages: 268,
          publishYear: 1932,
          language: "English",
          isbn: "978-0060850524",
          favorite: false
        },
        {
          id: 15,
          title: "The Hunger Games",
          author: "Suzanne Collins",
          genre: "Sci-Fi",
          description: "In the ruins of a place once known as North America lies the nation of Panem, a shining Capitol surrounded by twelve outlying districts.",
          pages: 374,
          publishYear: 2008,
          language: "English",
          isbn: "978-0439023481",
          favorite: false
        },
        // Fantasy
        {
          id: 16,
          title: "Game of Thrones",
          author: "George R.R. Martin",
          genre: "Fantasy",
          description: "In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes, sinister forces are massing.",
          pages: 694,
          publishYear: 1996,
          language: "English",
          isbn: "978-0553593716",
          favorite: false
        },
        {
          id: 17,
          title: "The Name of the Wind",
          author: "Patrick Rothfuss",
          genre: "Fantasy",
          description: "My name is Kvothe. I have stolen princesses back from sleeping barrow kings. I have spent the night with Felurian and left with both my sanity and my life.",
          pages: 662,
          publishYear: 2007,
          language: "English",
          isbn: "978-0756404741",
          favorite: false
        },
        {
          id: 18,
          title: "Mistborn",
          author: "Brandon Sanderson",
          genre: "Fantasy",
          description: "For a thousand years the ash fell and no flowers bloomed. For a thousand years the Skaa slaved in misery and lived in fear. For a thousand years the Lord Ruler reigned with absolute power and ultimate terror.",
          pages: 541,
          publishYear: 2006,
          language: "English",
          isbn: "978-0765350381",
          favorite: false
        },
        {
          id: 19,
          title: "The Chronicles of Narnia",
          author: "C.S. Lewis",
          genre: "Fantasy",
          description: "Epic fantasy series about four siblings who stumble into a magical world through an enchanted wardrobe.",
          pages: 767,
          publishYear: 1950,
          language: "English",
          isbn: "978-0066238500",
          favorite: false
        },
        {
          id: 20,
          title: "American Gods",
          author: "Neil Gaiman",
          genre: "Fantasy",
          description: "Shadow Moon, an ex-convict who is released from prison three days after his wife's death, meets the mysterious Mr. Wednesday and is recruited as his bodyguard.",
          pages: 465,
          publishYear: 2001,
          language: "English",
          isbn: "978-0380789030",
          favorite: false
        },
        // Mystery/Thriller
        {
          id: 21,
          title: "Gone Girl",
          author: "Gillian Flynn",
          genre: "Thriller",
          description: "On a warm summer morning in North Carthage, Missouri, it is Nick and Amy Dunne's fifth wedding anniversary. Presents are being wrapped and reservations are being made.",
          pages: 415,
          publishYear: 2012,
          language: "English",
          isbn: "978-0307588371",
          favorite: false
        },
        {
          id: 22,
          title: "The Girl with the Dragon Tattoo",
          author: "Stieg Larsson",
          genre: "Thriller",
          description: "Mikael Blomkvist, a journalist, and Lisbeth Salander, a computer hacker, investigate the disappearance of a wealthy industrialist's niece.",
          pages: 672,
          publishYear: 2005,
          language: "English",
          isbn: "978-0307269751",
          favorite: false
        },
        {
          id: 23,
          title: "And Then There Were None",
          author: "Agatha Christie",
          genre: "Thriller",
          description: "Ten strangers, apparently with little in common, are lured to an island mansion off the coast of Devon by the mysterious U.N. Owen.",
          pages: 264,
          publishYear: 1939,
          language: "English",
          isbn: "978-0062073488",
          favorite: false
        },
        {
          id: 24,
          title: "The Silence of the Lambs",
          author: "Thomas Harris",
          genre: "Thriller",
          description: "FBI trainee Clarice Starling is given an assignment to interview Dr. Hannibal Lecter, a brilliant psychiatrist and cannibalistic serial killer.",
          pages: 338,
          publishYear: 1988,
          language: "English",
          isbn: "978-0312924584",
          favorite: false
        },
        {
          id: 25,
          title: "The Shining",
          author: "Stephen King",
          genre: "Thriller",
          description: "Danny was only five years old but in the words of old Mr. Hallorann he was a 'shiner', aglow with psychic voltage.",
          pages: 447,
          publishYear: 1977,
          language: "English",
          isbn: "978-0307743657",
          favorite: false
        },
        // Non-Fiction
        {
          id: 26,
          title: "A Brief History of Time",
          author: "Stephen Hawking",
          genre: "Non-Fiction",
          description: "A landmark volume in science writing by one of the great minds of our time, Stephen Hawking's book explores profound questions about the universe.",
          pages: 212,
          publishYear: 1988,
          language: "English",
          isbn: "978-0553380163",
          favorite: false
        },
        {
          id: 27,
          title: "Sapiens",
          author: "Yuval Noah Harari",
          genre: "Non-Fiction",
          description: "A brief history of humankind, exploring how humans evolved from insignificant apes to rulers of the world.",
          pages: 443,
          publishYear: 2011,
          language: "English",
          isbn: "978-0062316097",
          favorite: false
        },
        {
          id: 28,
          title: "Thinking, Fast and Slow",
          author: "Daniel Kahneman",
          genre: "Non-Fiction",
          description: "The renowned psychologist explores the two systems that drive the way we think—System 1 is fast, intuitive, and emotional; System 2 is slower, more deliberative, and more logical.",
          pages: 499,
          publishYear: 2011,
          language: "English",
          isbn: "978-0374533557",
          favorite: false
        },
        {
          id: 29,
          title: "The Immortal Life of Henrietta Lacks",
          author: "Rebecca Skloot",
          genre: "Non-Fiction",
          description: "The story of Henrietta Lacks, a woman whose cells were taken without her knowledge and became one of the most important tools in medicine.",
          pages: 381,
          publishYear: 2010,
          language: "English",
          isbn: "978-1400052189",
          favorite: false
        },
        {
          id: 30,
          title: "Educated",
          author: "Tara Westover",
          genre: "Non-Fiction",
          description: "A memoir about a woman who was kept out of school as a child by her survivalist parents and went on to earn a PhD from Cambridge University.",
          pages: 334,
          publishYear: 2018,
          language: "English",
          isbn: "978-0399590504",
          favorite: false
        },
        // Classic
        {
          id: 31,
          title: "Moby-Dick",
          author: "Herman Melville",
          genre: "Classic",
          description: "The saga of Captain Ahab and his monomaniacal pursuit of the white whale remains the greatest sea story ever told.",
          pages: 585,
          publishYear: 1851,
          language: "English",
          isbn: "978-0142437247",
          favorite: false
        },
        {
          id: 32,
          title: "War and Peace",
          author: "Leo Tolstoy",
          genre: "Classic",
          description: "Epic in scale, War and Peace delineates in graphic detail events leading up to Napoleon's invasion of Russia.",
          pages: 1225,
          publishYear: 1869,
          language: "English",
          isbn: "978-0143039990",
          favorite: false
        },
        {
          id: 33,
          title: "Jane Eyre",
          author: "Charlotte Brontë",
          genre: "Classic",
          description: "Orphaned into the household of her Aunt Reed, Jane Eyre endures a childhood of cruelty before being sent to the Lowood School, a miserable institution.",
          pages: 532,
          publishYear: 1847,
          language: "English",
          isbn: "978-0142437209",
          favorite: false
        },
        {
          id: 34,
          title: "Don Quixote",
          author: "Miguel de Cervantes",
          genre: "Classic",
          description: "Retired country gentleman Alonso Quijano loses his sanity after reading too many chivalric romances and decides to become a knight-errant.",
          pages: 940,
          publishYear: 1605,
          language: "English",
          isbn: "978-0060934347",
          favorite: false
        },
        {
          id: 35,
          title: "Crime and Punishment",
          author: "Fyodor Dostoevsky",
          genre: "Classic",
          description: "A novel focusing on the mental anguish and moral dilemmas of Rodion Raskolnikov, an impoverished ex-student in Saint Petersburg who formulates a plan to kill an unscrupulous pawnbroker.",
          pages: 545,
          publishYear: 1866,
          language: "English",
          isbn: "978-0143058144",
          favorite: false
        },
        // Romance
        {
          id: 36,
          title: "Outlander",
          author: "Diana Gabaldon",
          genre: "Romance",
          description: "The year is 1945. Claire Randall, a former combat nurse, is back from the war and reunited with her husband on a second honeymoon when she walks through a standing stone in the British Isles.",
          pages: 850,
          publishYear: 1991,
          language: "English",
          isbn: "978-0440212560",
          favorite: false
        },
        {
          id: 37,
          title: "Me Before You",
          author: "Jojo Moyes",
          genre: "Romance",
          description: "Louisa Clark is an ordinary girl living an exceedingly ordinary life who has barely been farther afield than their tiny village.",
          pages: 369,
          publishYear: 2012,
          language: "English",
          isbn: "978-0143124542",
          favorite: false
        },
        {
          id: 38,
          title: "The Notebook",
          author: "Nicholas Sparks",
          genre: "Romance",
          description: "A man with a faded, well-worn notebook, retelling a story that evokes a passionate, bittersweet tale of a young love so intense it became dangerous.",
          pages: 214,
          publishYear: 1996,
          language: "English",
          isbn: "978-0553593419",
          favorite: false
        },
        {
          id: 39,
          title: "The Time Traveler's Wife",
          author: "Audrey Niffenegger",
          genre: "Romance",
          description: "A love story about a man with a genetic disorder that causes him to time travel unpredictably, and about his wife, who has to cope with his frequent absences.",
          pages: 546,
          publishYear: 2003,
          language: "English",
          isbn: "978-0099546184",
          favorite: false
        },
        {
          id: 40,
          title: "The Fault in Our Stars",
          author: "John Green",
          genre: "Romance",
          description: "A heartbreaking love story about two teenagers who are dying of cancer but find in each other an escape from their suffering.",
          pages: 313,
          publishYear: 2012,
          language: "English",
          isbn: "978-0142424179",
          favorite: false
        },
        // Historical Fiction
        {
          id: 41,
          title: "All the Light We Cannot See",
          author: "Anthony Doerr",
          genre: "Historical Fiction",
          description: "A beautiful, stunningly ambitious novel about a blind French girl and a German boy whose paths collide in occupied France during World War II.",
          pages: 531,
          publishYear: 2014,
          language: "English",
          isbn: "978-1501173219",
          favorite: false
        },
        {
          id: 42,
          title: "The Book Thief",
          author: "Markus Zusak",
          genre: "Historical Fiction",
          description: "The story of Liesel Meminger, a young girl living with her foster parents in Nazi Germany during World War II.",
          pages: 584,
          publishYear: 2005,
          language: "English",
          isbn: "978-0375842207",
          favorite: false
        },
        {
          id: 43,
          title: "The Pillars of the Earth",
          author: "Ken Follett",
          genre: "Historical Fiction",
          description: "A spellbinding epic set in twelfth-century England, The Pillars of the Earth tells the story of the building of a cathedral in the fictional town of Kingsbridge.",
          pages: 973,
          publishYear: 1989,
          language: "English",
          isbn: "978-0451226891",
          favorite: false
        },
        {
          id: 44,
          title: "Wolf Hall",
          author: "Hilary Mantel",
          genre: "Historical Fiction",
          description: "England in the 1520s is a heartbeat from disaster. If the king dies without a male heir, the country could be destroyed by civil war.",
          pages: 604,
          publishYear: 2009,
          language: "English",
          isbn: "978-0007230204",
          favorite: false
        },
        {
          id: 45,
          title: "The Nightingale",
          author: "Kristin Hannah",
          genre: "Historical Fiction",
          description: "The Nightingale tells the stories of two sisters, separated by years and experience, by ideals, passion, and circumstance, each embarking on her own dangerous path toward survival.",
          pages: 440,
          publishYear: 2015,
          language: "English",
          isbn: "978-0312577223",
          favorite: false
        },
        // Young Adult
        {
          id: 46,
          title: "The Hate U Give",
          author: "Angie Thomas",
          genre: "Young Adult",
          description: "Sixteen-year-old Starr Carter moves between two worlds: the poor neighborhood where she lives and the fancy suburban prep school she attends.",
          pages: 444,
          publishYear: 2017,
          language: "English",
          isbn: "978-0062498533",
          favorite: false
        },
        {
          id: 47,
          title: "The Perks of Being a Wallflower",
          author: "Stephen Chbosky",
          genre: "Young Adult",
          description: "A story about a high school freshman who writes letters about his experiences to an anonymous recipient.",
          pages: 213,
          publishYear: 1999,
          language: "English",
          isbn: "978-0671027346",
          favorite: false
        },
        {
          id: 48,
          title: "Divergent",
          author: "Veronica Roth",
          genre: "Young Adult",
          description: "In a future society divided into five factions based on personality type, Beatrice Prior must choose her faction while hiding a dangerous secret.",
          pages: 487,
          publishYear: 2011,
          language: "English",
          isbn: "978-0062024022",
          favorite: false
        },
        {
          id: 49,
          title: "Thirteen Reasons Why",
          author: "Jay Asher",
          genre: "Young Adult",
          description: "Clay Jensen returns home from school to find a strange package with his name on it lying on his porch. Inside he discovers several cassette tapes recorded by Hannah Baker.",
          pages: 288,
          publishYear: 2007,
          language: "English",
          isbn: "978-1595141880",
          favorite: false
        },
        {
          id: 50,
          title: "Looking for Alaska",
          author: "John Green",
          genre: "Young Adult",
          description: "Miles Halter is fascinated by famous last words and tired of his safe life at home. He leaves for Culver Creek Boarding School to seek what the dying poet François Rabelais called 'The Great Perhaps.'",
          pages: 221,
          publishYear: 2005,
          language: "English",
          isbn: "978-0142402511",
          favorite: false
        },
        // More Fiction
        {
          id: 51,
          title: "The Kite Runner",
          author: "Khaled Hosseini",
          genre: "Fiction",
          description: "The unforgettable, heartbreaking story of the unlikely friendship between a wealthy boy and the son of his father's servant.",
          pages: 371,
          publishYear: 2003,
          language: "English",
          isbn: "978-1594631931",
          favorite: false
        },
        {
          id: 52,
          title: "The Handmaid's Tale",
          author: "Margaret Atwood",
          genre: "Fiction",
          description: "Set in a near-future New England, in a totalitarian state resembling a theonomy that has overthrown the United States government.",
          pages: 311,
          publishYear: 1985,
          language: "English",
          isbn: "978-0385490818",
          favorite: false
        },
        {
          id: 53,
          title: "One Hundred Years of Solitude",
          author: "Gabriel García Márquez",
          genre: "Fiction",
          description: "The novel tells the story of the Buendía family, whose patriarch, José Arcadio Buendía, founded the town of Macondo, a fictional town in the country of Colombia.",
          pages: 417,
          publishYear: 1967,
          language: "English",
          isbn: "978-0060883287",
          favorite: false
        },
        {
          id: 54,
          title: "Fahrenheit 451",
          author: "Ray Bradbury",
          genre: "Fiction",
          description: "Guy Montag is a fireman. In his world, where television rules and literature is on the brink of extinction, firemen start fires rather than put them out.",
          pages: 249,
          publishYear: 1953,
          language: "English",
          isbn: "978-1451673319",
          favorite: false
        },
        {
          id: 55,
          title: "Slaughterhouse-Five",
          author: "Kurt Vonnegut",
          genre: "Fiction",
          description: "Billy Pilgrim becomes unstuck in time after he is abducted by aliens from the planet Tralfamadore.",
          pages: 275,
          publishYear: 1969,
          language: "English",
          isbn: "978-0385333849",
          favorite: false
        },
        // More books (continuing to 100+)
        {
          id: 56,
          title: "The Alchemist",
          author: "Paulo Coelho",
          genre: "Fiction",
          description: "The mystical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure.",
          pages: 197,
          publishYear: 1988,
          language: "English",
          isbn: "978-0062315007",
          favorite: false
        },
        {
          id: 57,
          title: "The Road",
          author: "Cormac McCarthy",
          genre: "Fiction",
          description: "A father and his son walk alone through burned America, heading through the ravaged landscape to the coast.",
          pages: 287,
          publishYear: 2006,
          language: "English",
          isbn: "978-0307387899",
          favorite: false
        },
        {
          id: 58,
          title: "The Giver",
          author: "Lois Lowry",
          genre: "Young Adult",
          description: "The story of a boy named Jonas who lives in a seemingly ideal world. Not until he is given his life assignment as the Receiver does he begin to understand the dark secrets behind this fragile community.",
          pages: 208,
          publishYear: 1993,
          language: "English",
          isbn: "978-0544336261",
          favorite: false
        },
        {
          id: 59,
          title: "The Color Purple",
          author: "Alice Walker",
          genre: "Fiction",
          description: "The Color Purple depicts the lives of African American women in early twentieth-century rural Georgia.",
          pages: 295,
          publishYear: 1982,
          language: "English",
          isbn: "978-0156028356",
          favorite: false
        },
        {
          id: 60,
          title: "A Game of Thrones",
          author: "George R.R. Martin",
          genre: "Fantasy",
          description: "In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes, sinister forces are massing.",
          pages: 694,
          publishYear: 1996,
          language: "English",
          isbn: "978-0553593716",
          favorite: false
        },
        // More epic and diverse titles
        {
          id: 61,
          title: "Little Women",
          author: "Louisa May Alcott",
          genre: "Classic",
          description: "Following the lives of the four March sisters—Meg, Jo, Beth, and Amy—and their passage from childhood to womanhood.",
          pages: 449,
          publishYear: 1868,
          language: "English",
          isbn: "978-0143106659",
          favorite: false
        },
        {
          id: 62,
          title: "The Odyssey",
          author: "Homer",
          genre: "Classic",
          description: "The Odyssey is one of two major ancient Greek epic poems attributed to Homer. It is one of the oldest works of literature still read by contemporary audiences.",
          pages: 442,
          publishYear: -800,
          language: "English",
          isbn: "978-0140268867",
          favorite: false
        },
        {
          id: 63,
          title: "Frankenstein",
          author: "Mary Shelley",
          genre: "Classic",
          description: "The story of Victor Frankenstein, a young scientist who creates a hideous sapient creature in an unorthodox scientific experiment.",
          pages: 280,
          publishYear: 1818,
          language: "English",
          isbn: "978-0486282114",
          favorite: false
        },
        {
          id: 64,
          title: "The Martian",
          author: "Andy Weir",
          genre: "Sci-Fi",
          description: "Six days ago, astronaut Mark Watney became one of the first people to walk on Mars. Now, he's sure he'll be the first person to die there.",
          pages: 369,
          publishYear: 2011,
          language: "English",
          isbn: "978-0553418026",
          favorite: false
        },
        {
          id: 65,
          title: "The Catch-22",
          author: "Joseph Heller",
          genre: "Fiction",
          description: "A satirical war novel that follows Captain John Yossarian, a U.S. Army Air Forces B-25 bombardier, and a number of other characters.",
          pages: 453,
          publishYear: 1961,
          language: "English",
          isbn: "978-0684833392",
          favorite: false
        },
        {
          id: 66,
          title: "The Grapes of Wrath",
          author: "John Steinbeck",
          genre: "Fiction",
          description: "The story of the Joads, an Oklahoma farm family, during the Great Depression and the Dust Bowl.",
          pages: 464,
          publishYear: 1939,
          language: "English",
          isbn: "978-0143039433",
          favorite: false
        },
        {
          id: 67,
          title: "The Picture of Dorian Gray",
          author: "Oscar Wilde",
          genre: "Classic",
          description: "A philosophical novel that tells the story of a young man whose portrait ages while he remains youthful and beautiful.",
          pages: 272,
          publishYear: 1890,
          language: "English",
          isbn: "978-0141439570",
          favorite: false
        },
        {
          id: 68,
          title: "The Sun Also Rises",
          author: "Ernest Hemingway",
          genre: "Fiction",
          description: "A group of American and British expatriates who travel from Paris to the Festival of San Fermín in Pamplona to watch the running of the bulls and the bullfights.",
          pages: 251,
          publishYear: 1926,
          language: "English",
          isbn: "978-0743297332",
          favorite: false
        },
        {
          id: 69,
          title: "The Call of the Wild",
          author: "Jack London",
          genre: "Adventure",
          description: "A dog named Buck is stolen from his home and sold into service as a sled dog in Alaska.",
          pages: 172,
          publishYear: 1903,
          language: "English",
          isbn: "978-0486264727",
          favorite: false
        },
        {
          id: 70,
          title: "Great Expectations",
          author: "Charles Dickens",
          genre: "Classic",
          description: "The story of the orphan Pip and his growth and personal development as he moves through different stages of his life.",
          pages: 544,
          publishYear: 1861,
          language: "English",
          isbn: "978-0141439563",
          favorite: false
        },
        // More classics and modern favorites
        {
          id: 71,
          title: "Anne of Green Gables",
          author: "Lucy Maud Montgomery",
          genre: "Classic",
          description: "The adventures of Anne Shirley, an 11-year-old orphan girl who is mistakenly sent to Matthew and Marilla Cuthbert, a middle-aged brother and sister.",
          pages: 320,
          publishYear: 1908,
          language: "English",
          isbn: "978-0141321592",
          favorite: false
        },
        {
          id: 72,
          title: "The Old Man and the Sea",
          author: "Ernest Hemingway",
          genre: "Fiction",
          description: "The story of an aging Cuban fisherman who struggles with a giant marlin far out in the Gulf Stream.",
          pages: 127,
          publishYear: 1952,
          language: "English",
          isbn: "978-0684801223",
          favorite: false
        },
        {
          id: 73,
          title: "Lord of the Flies",
          author: "William Golding",
          genre: "Fiction",
          description: "A group of British boys stuck on an uninhabited island who try to govern themselves with disastrous results.",
          pages: 224,
          publishYear: 1954,
          language: "English",
          isbn: "978-0399501487",
          favorite: false
        },
        {
          id: 74,
          title: "The Bell Jar",
          author: "Sylvia Plath",
          genre: "Fiction",
          description: "Chronicles the crack-up of Esther Greenwood: brilliant, beautiful, enormously talented, and successful, but slowly going under.",
          pages: 244,
          publishYear: 1963,
          language: "English",
          isbn: "978-0060837020",
          favorite: false
        },
        {
          id: 75,
          title: "Animal Farm",
          author: "George Orwell",
          genre: "Fiction",
          description: "A farm is taken over by its overworked, mistreated animals. They set up a form of government where everyone is equal.",
          pages: 141,
          publishYear: 1945,
          language: "English",
          isbn: "978-0451526342",
          favorite: false
        },
        {
          id: 76,
          title: "The Count of Monte Cristo",
          author: "Alexandre Dumas",
          genre: "Adventure",
          description: "In 1815 Edmond Dantès is betrayed by his enemies and thrown into a dungeon. After 14 years he escapes and sets about using his hidden fortune to exact revenge.",
          pages: 1276,
          publishYear: 1844,
          language: "English",
          isbn: "978-0140449266",
          favorite: false
        },
        {
          id: 77,
          title: "Les Misérables",
          author: "Victor Hugo",
          genre: "Classic",
          description: "The story of Jean Valjean, a former convict who tries to redeem himself, and his struggle against the vengeful police inspector Javert.",
          pages: 1463,
          publishYear: 1862,
          language: "English",
          isbn: "978-0451419439",
          favorite: false
        },
        {
          id: 78,
          title: "Dracula",
          author: "Bram Stoker",
          genre: "Horror",
          description: "The classic vampire story about Count Dracula's attempt to move from Transylvania to England to spread the undead curse.",
          pages: 418,
          publishYear: 1897,
          language: "English",
          isbn: "978-0486411095",
          favorite: false
        },
        {
          id: 79,
          title: "Wuthering Heights",
          author: "Emily Brontë",
          genre: "Classic",
          description: "The story of the passionate love between the wild Heathcliff and Catherine Earnshaw that eventually destroys them both.",
          pages: 416,
          publishYear: 1847,
          language: "English",
          isbn: "978-0141439556",
          favorite: false
        },
        {
          id: 80,
          title: "Heart of Darkness",
          author: "Joseph Conrad",
          genre: "Fiction",
          description: "A voyage up the Congo River by Charles Marlow, the narrator, to meet Kurtz, a remarkable man stationed there.",
          pages: 188,
          publishYear: 1899,
          language: "English",
          isbn: "978-0141441672",
          favorite: false
        },
        // Final section to reach over 100
        {
          id: 81,
          title: "Hamlet",
          author: "William Shakespeare",
          genre: "Classic",
          description: "The Tragedy of Hamlet, Prince of Denmark, is a play about the revenge Prince Hamlet exacts for his father's murder.",
          pages: 342,
          publishYear: 1603,
          language: "English",
          isbn: "978-0743477123",
          favorite: false
        },
        {
          id: 82,
          title: "The Divine Comedy",
          author: "Dante Alighieri",
          genre: "Classic",
          description: "A long narrative poem representing the soul's journey to God.",
          pages: 798,
          publishYear: 1320,
          language: "English",
          isbn: "978-0451208637",
          favorite: false
        },
        {
          id: 83,
          title: "The Canterbury Tales",
          author: "Geoffrey Chaucer",
          genre: "Classic",
          description: "A collection of 24 stories that runs to over 17,000 lines written in Middle English by Geoffrey Chaucer between 1387 and 1400.",
          pages: 504,
          publishYear: 1400,
          language: "English",
          isbn: "978-0140424386",
          favorite: false
        },
        {
          id: 84,
          title: "The Iliad",
          author: "Homer",
          genre: "Classic",
          description: "An ancient Greek epic poem set during the Trojan War, the ten-year siege of the city of Troy by a coalition of Greek states.",
          pages: 683,
          publishYear: -800,
          language: "English",
          isbn: "978-0140275360",
          favorite: false
        },
        {
          id: 85,
          title: "The Brothers Karamazov",
          author: "Fyodor Dostoevsky",
          genre: "Classic",
          description: "A passionate philosophical novel that explores faith, doubt, and reason in the context of a modernizing Russia.",
          pages: 796,
          publishYear: 1880,
          language: "English",
          isbn: "978-0374528379",
          favorite: false
        },
        {
          id: 86,
          title: "The Stranger",
          author: "Albert Camus",
          genre: "Fiction",
          description: "A man who commits a senseless murder and is devoid of normal human emotion.",
          pages: 123,
          publishYear: 1942,
          language: "English",
          isbn: "978-0679720201",
          favorite: false
        },
        {
          id: 87,
          title: "A Tale of Two Cities",
          author: "Charles Dickens",
          genre: "Classic",
          description: "A novel set in London and Paris before and during the French Revolution.",
          pages: 489,
          publishYear: 1859,
          language: "English",
          isbn: "978-0141439600",
          favorite: false
        },
        {
          id: 88,
          title: "The Scarlet Letter",
          author: "Nathaniel Hawthorne",
          genre: "Classic",
          description: "Set in 17th-century Puritan Massachusetts Bay Colony, the novel tells the story of Hester Prynne who conceives a daughter through an affair.",
          pages: 238,
          publishYear: 1850,
          language: "English",
          isbn: "978-0486280486",
          favorite: false
        },
        {
          id: 89,
          title: "Brave New World",
          author: "Aldous Huxley",
          genre: "Sci-Fi",
          description: "A futuristic society that has genetically modified citizens to fit into a rigid social hierarchy.",
          pages: 288,
          publishYear: 1932,
          language: "English",
          isbn: "978-0060850524",
          favorite: false
        },
        {
          id: 90,
          title: "Anna Karenina",
          author: "Leo Tolstoy",
          genre: "Classic",
          description: "A complex novel in eight parts, with more than a dozen major characters, spanning the aristocracy to the peasantry.",
          pages: 864,
          publishYear: 1877,
          language: "English",
          isbn: "978-0143035008",
          favorite: false
        },
        {
          id: 91,
          title: "The Adventures of Huckleberry Finn",
          author: "Mark Twain",
          genre: "Classic",
          description: "Commonly named among the Great American Novels, the work is among the first in major American literature to be written throughout in vernacular English.",
          pages: 366,
          publishYear: 1884,
          language: "English",
          isbn: "978-0486280486",
          favorite: false
        },
        {
          id: 92,
          title: "The Great American Novel",
          author: "Philip Roth",
          genre: "Fiction",
          description: "A satirical novel that follows the fortunes of a baseball team called the Ruppert Mundys.",
          pages: 382,
          publishYear: 1973,
          language: "English",
          isbn: "978-0679749066",
          favorite: false
        },
        {
          id: 93,
          title: "The Wind in the Willows",
          author: "Kenneth Grahame",
          genre: "Children's",
          description: "A classic of children's literature, first published in 1908, mainly about four anthropomorphised animals.",
          pages: 256,
          publishYear: 1908,
          language: "English",
          isbn: "978-0143039099",
          favorite: false
        },
        {
          id: 94,
          title: "Alice's Adventures in Wonderland",
          author: "Lewis Carroll",
          genre: "Children's",
          description: "A novel about a girl named Alice falling through a rabbit hole into a fantasy world populated by peculiar, anthropomorphic creatures.",
          pages: 200,
          publishYear: 1865,
          language: "English",
          isbn: "978-0141439761",
          favorite: false
        },
        {
          id: 95,
          title: "The Secret Garden",
          author: "Frances Hodgson Burnett",
          genre: "Children's",
          description: "A novel about a particularly disagreeable and self-centered little girl who is forced to live with her uncle in England after her parents die.",
          pages: 242,
          publishYear: 1911,
          language: "English",
          isbn: "978-0141321066",
          favorite: false
        },
        {
          id: 96,
          title: "The Wonderful Wizard of Oz",
          author: "L. Frank Baum",
          genre: "Children's",
          description: "The story of a young Kansas girl named Dorothy Gale who is swept away by a cyclone to the magical Land of Oz.",
          pages: 218,
          publishYear: 1900,
          language: "English",
          isbn: "978-0141321028",
          favorite: false
        },
        {
          id: 97,
          title: "Charlotte's Web",
          author: "E.B. White",
          genre: "Children's",
          description: "The story of a pig named Wilbur and his friendship with a barn spider named Charlotte.",
          pages: 192,
          publishYear: 1952,
          language: "English",
          isbn: "978-0064410939",
          favorite: false
        },
        {
          id: 98,
          title: "Charlie and the Chocolate Factory",
          author: "Roald Dahl",
          genre: "Children's",
          description: "A children's novel featuring the adventures of young Charlie Bucket inside the chocolate factory of eccentric chocolatier Willy Wonka.",
          pages: 176,
          publishYear: 1964,
          language: "English",
          isbn: "978-0142410318",
          favorite: false
        },
        {
          id: 99,
          title: "Watership Down",
          author: "Richard Adams",
          genre: "Fantasy",
          description: "An adventure novel that depicts a small group of rabbits in search of a new home after their original warren is threatened.",
          pages: 496,
          publishYear: 1972,
          language: "English",
          isbn: "978-0743277709",
          favorite: false
        },
        {
          id: 100,
          title: "The Little Prince",
          author: "Antoine de Saint-Exupéry",
          genre: "Children's",
          description: "A novella about a young prince who visits various planets in space, including Earth, and addresses themes of loneliness, friendship, love, and loss.",
          pages: 96,
          publishYear: 1943,
          language: "English",
          isbn: "978-0156012195",
          favorite: false
        },
        {
          id: 101,
          title: "Where the Wild Things Are",
          author: "Maurice Sendak",
          genre: "Children's",
          description: "A story about a boy named Max who, after dressing in his wolf costume, wreaks havoc through his household and is sent to bed without his supper.",
          pages: 48,
          publishYear: 1963,
          language: "English",
          isbn: "978-0064431781",
          favorite: false
        },
        {
          id: 102,
          title: "The Jungle Book",
          author: "Rudyard Kipling",
          genre: "Children's",
          description: "A collection of stories set in a jungle in India, most of which involve the character Mowgli, a boy raised by wolves.",
          pages: 240,
          publishYear: 1894,
          language: "English",
          isbn: "978-0141325293",
          favorite: false
        }
      ];

      // Get favorites from local storage
      const favorites = getLocalStorage("favorites") || [];
      
      // Apply favorites
      const booksWithFavorites = staticBooks.map(book => ({
        ...book,
        favorite: favorites.includes(book.id)
      }));
      
      setBooks(booksWithFavorites);
      
    } catch (err) {
      console.error("Error loading books:", err);
      setError("Failed to load books. Please try again.");
      toast.error("Failed to load books");
    } finally {
      setLoading(false);
    }
  }, []);

  // Toggle favorite status
  const toggleFavorite = useCallback((id: number) => {
    // Get existing favorites
    const favorites = getLocalStorage("favorites") || [];
    let newFavorites;
    
    if (favorites.includes(id)) {
      // Remove from favorites
      newFavorites = favorites.filter((favId: number) => favId !== id);
      toast.success("Removed from favorites");
    } else {
      // Add to favorites
      newFavorites = [...favorites, id];
      toast.success("Added to favorites");
    }
    
    // Save to local storage
    setLocalStorage("favorites", newFavorites);
    
    // Update books state
    setBooks(prevBooks => 
      prevBooks.map(book => 
        book.id === id 
          ? { ...book, favorite: !book.favorite } 
          : book
      )
    );
  }, []);

  // Toggle showing favorites only
  const toggleShowFavorites = useCallback(() => {
    setShowFavorites(prev => !prev);
  }, []);

  // Apply filters, sorting, and search
  const filteredBooks = useMemo(() => {
    let result = [...books];
    
    // Filter by genre if selected
    if (genreFilter) {
      result = result.filter(book => book.genre === genreFilter);
    }
    
    // Filter favorites if showing favorites only
    if (showFavorites) {
      result = result.filter(book => book.favorite);
    }
    
    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        book =>
          book.title.toLowerCase().includes(query) ||
          book.author.toLowerCase().includes(query) ||
          book.genre.toLowerCase().includes(query)
      );
    }
    
    // Apply sorting
    result.sort((a, b) => {
      switch (sort) {
        case "author":
          return a.author.localeCompare(b.author);
        case "recent":
          return b.publishYear - a.publishYear;
        case "title":
        default:
          return a.title.localeCompare(b.title);
      }
    });
    
    return result;
  }, [books, genreFilter, showFavorites, sort, searchQuery]);

  const value = {
    books,
    filteredBooks,
    loading,
    error,
    genreFilter,
    showFavorites,
    sort,
    searchQuery,
    fetchBooks,
    setGenreFilter,
    toggleShowFavorites,
    toggleFavorite,
    setSort,
    setSearchQuery
  };

  return (
    <BooksContext.Provider value={value}>{children}</BooksContext.Provider>
  );
}

export function useBooks() {
  const context = useContext(BooksContext);
  if (!context) {
    throw new Error("useBooks must be used within a BooksProvider");
  }
  return context;
}
