import { useState, useEffect } from "react";
import { useBooks } from "@/lib/stores/useBooks";

interface GenreFilterProps {
  onChange: (genre: string | null) => void;
}

export default function GenreFilter({ onChange }: GenreFilterProps) {
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const { books, loading } = useBooks();
  
  // Get unique genres from books
  const genres = [...new Set(books.map(book => book.genre))].sort();
  
  const handleGenreChange = (genre: string | null) => {
    setSelectedGenre(genre);
    onChange(genre);
  };

  return (
    <div className="relative">
      <select
        className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
        value={selectedGenre || ""}
        onChange={(e) => handleGenreChange(e.target.value === "" ? null : e.target.value)}
        disabled={loading}
      >
        <option value="">All Genres</option>
        {genres.map((genre) => (
          <option key={genre} value={genre}>
            {genre}
          </option>
        ))}
      </select>
      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
        <svg
          className="w-5 h-5 text-gray-400"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path
            fillRule="evenodd"
            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
            clipRule="evenodd"
          />
        </svg>
      </div>
    </div>
  );
}
