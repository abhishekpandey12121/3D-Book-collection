import { useRef, useState, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useTexture, Text } from "@react-three/drei";
import { Group, Mesh, MathUtils } from "three";
import * as THREE from "three";
import { useBooks } from "@/lib/stores/useBooks";
import { BookType } from "@/lib/types";
import FavoriteButton from "./FavoriteButton";
import { Event } from "three";

interface BookProps {
  book: BookType;
  index: number;
  isSelected: boolean;
  onClick: () => void;
  position: [number, number, number];
}

export default function Book({ book, index, isSelected, onClick, position }: BookProps) {
  const ref = useRef<Group>(null);
  const bookRef = useRef<Mesh>(null);
  const { viewport } = useThree();
  const [hovered, setHovered] = useState(false);
  const { toggleFavorite } = useBooks();
  
  // Load wood texture for book cover
  const texture = useTexture("/textures/wood.jpg");
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(0.5, 0.5);
  
  // Animation parameters
  const raisedPosition = 0.5;
  const baseScale = 1;
  const hoverScale = 1.1;
  
  // Handle hover animation
  useEffect(() => {
    document.body.style.cursor = hovered ? "pointer" : "auto";
  }, [hovered]);

  // Book animation
  useFrame((_, delta) => {
    if (!ref.current) return;
    
    // Bobbing animation for non-selected books
    if (!isSelected) {
      ref.current.position.y = position[1] + Math.sin(Date.now() * 0.001 + index * 0.5) * 0.05;
    }
    
    // When selected, raise the book
    const targetY = isSelected ? position[1] + raisedPosition : position[1];
    ref.current.position.y = MathUtils.lerp(ref.current.position.y, targetY, delta * 5);
    
    // Scale up on hover or selection
    const targetScale = hovered || isSelected ? hoverScale : baseScale;
    if (bookRef.current) {
      bookRef.current.scale.x = MathUtils.lerp(bookRef.current.scale.x, targetScale, delta * 5);
      bookRef.current.scale.y = MathUtils.lerp(bookRef.current.scale.y, targetScale, delta * 5);
      bookRef.current.scale.z = MathUtils.lerp(bookRef.current.scale.z, targetScale, delta * 5);
    }
    
    // Rotate when selected for display
    const targetRotationY = isSelected ? Math.PI * 0.1 : 0;
    ref.current.rotation.y = MathUtils.lerp(ref.current.rotation.y, targetRotationY, delta * 3);
  });
  
  // Determine book cover color based on genre
  const getBookColor = () => {
    switch(book.genre) {
      case "Fiction": return "#1e3a8a"; // Blue
      case "Fantasy": return "#065f46"; // Green
      case "Sci-Fi": return "#7c3aed"; // Purple
      case "Thriller": return "#b91c1c"; // Red
      case "Romance": return "#db2777"; // Pink
      case "Biography": return "#92400e"; // Brown
      case "History": return "#854d0e"; // Amber
      default: return "#1f2937"; // Gray
    }
  };

  return (
    <group 
      ref={ref}
      position={[position[0], position[1], position[2]]}
      onClick={(e: any) => {
        e.stopPropagation();
        onClick();
      }}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Book */}
      <mesh ref={bookRef} castShadow receiveShadow>
        {/* Book cover */}
        <boxGeometry args={[0.8, 1.2, 0.1]} />
        <meshStandardMaterial 
          map={texture} 
          color={getBookColor()} 
          roughness={0.8}
          metalness={0.2}
        />
        
        {/* Book spine with gold lettering effect */}
        <mesh position={[-0.4, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
          <boxGeometry args={[0.1, 1.2, 0.05]} />
          <meshStandardMaterial color={getBookColor()} roughness={0.7} metalness={0.3} />
        </mesh>
      </mesh>
      
      {/* Book title */}
      <Text
        position={[0, 0, 0.06]}
        fontSize={0.12}
        maxWidth={0.7}
        lineHeight={1}
        textAlign="center"
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {book.title}
      </Text>
      
      {/* Author */}
      <Text
        position={[0, -0.4, 0.06]}
        fontSize={0.08}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {book.author}
      </Text>
      
      {/* Favorite indicator */}
      <FavoriteButton
        position={[0.25, 0.45, 0.06]}
        isFavorite={book.favorite}
        onClick={(e: any) => {
          e.stopPropagation();
          toggleFavorite(book.id);
        }}
        scale={0.15}
      />
    </group>
  );
}
