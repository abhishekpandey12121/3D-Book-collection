import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Mesh, Vector3 } from "three";
import * as THREE from "three";

interface FavoriteButtonProps {
  position: [number, number, number];
  isFavorite: boolean;
  onClick: (e: any) => void;
  scale?: number;
}

export default function FavoriteButton({ 
  position, 
  isFavorite, 
  onClick, 
  scale = 1 
}: FavoriteButtonProps) {
  const ref = useRef<Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  // Handle hover animation
  useFrame((_, delta) => {
    if (!ref.current) return;
    
    // Pulse if hovered or favorite
    if (hovered || isFavorite) {
      ref.current.scale.x = THREE.MathUtils.lerp(
        ref.current.scale.x,
        scale * (1 + Math.sin(Date.now() * 0.008) * 0.08),
        delta * 5
      );
      ref.current.scale.y = ref.current.scale.x;
      ref.current.scale.z = ref.current.scale.x;
    } else {
      ref.current.scale.x = THREE.MathUtils.lerp(ref.current.scale.x, scale, delta * 5);
      ref.current.scale.y = ref.current.scale.x;
      ref.current.scale.z = ref.current.scale.x;
    }
  });

  // Create a simple heart shape
  const createHeartShape = () => {
    const shape = new THREE.Shape();
    const x = 0, y = 0;
    
    shape.moveTo(x, y + 0.25);
    shape.bezierCurveTo(x, y + 0.25, x - 0.25, y, x - 0.25, y);
    shape.bezierCurveTo(x - 0.25, y - 0.25, x, y - 0.5, x, y - 0.5);
    shape.bezierCurveTo(x, y - 0.5, x + 0.25, y - 0.25, x + 0.25, y);
    shape.bezierCurveTo(x + 0.25, y, x, y + 0.25, x, y + 0.25);
    
    return new THREE.ExtrudeGeometry(shape, {
      depth: 0.1,
      bevelEnabled: true,
      bevelSegments: 3,
      bevelSize: 0.05,
      bevelThickness: 0.05
    });
  };

  return (
    <mesh
      ref={ref}
      position={new Vector3(...position)}
      onClick={onClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      scale={scale}
    >
      <primitive object={createHeartShape()} />
      <meshStandardMaterial 
        color={isFavorite ? "#f59e0b" : "#6b7280"} 
        roughness={0.3}
        metalness={0.7}
        emissive={isFavorite ? "#f97316" : "#000000"}
        emissiveIntensity={isFavorite ? 0.5 : 0}
      />
    </mesh>
  );
}
