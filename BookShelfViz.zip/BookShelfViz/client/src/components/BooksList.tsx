import { useEffect, useMemo, useState } from "react";
import { useThree } from "@react-three/fiber";
import Book from "./Book";
import { useBooks } from "@/lib/stores/useBooks";

interface BooksListProps {
  onSelectBook: (id: number | null) => void;
}

export default function BooksList({ onSelectBook }: BooksListProps) {
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const { viewport } = useThree();
  const { books, filteredBooks, fetchBooks, loading } = useBooks();
  
  // Fetch books on component mount
  useEffect(() => {
    fetchBooks();
  }, [fetchBooks]);
  
  // Handle book selection
  const handleSelectBook = (id: number) => {
    if (selectedBookId === id) {
      setSelectedBookId(null);
      onSelectBook(null);
    } else {
      setSelectedBookId(id);
      onSelectBook(id);
    }
  };
  
  // Calculate positions for the books in a grid layout
  const positions = useMemo(() => {
    const isMobile = viewport.width < 5;
    const booksPerRow = isMobile ? 3 : 7; // Increased books per row for desktop
    return filteredBooks.map((_, index) => {
      const row = Math.floor(index / booksPerRow);
      const col = index % booksPerRow;
      
      // Create a grid layout
      let x = (col - (booksPerRow - 1) / 2) * 1.1; // Slightly narrower spacing
      let y = 0;
      let z = row * -1.3; // Tighter row spacing
      
      return [x, y, z] as [number, number, number];
    });
  }, [filteredBooks, viewport.width]);

  if (loading) {
    return (
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshStandardMaterial color="white" wireframe />
      </mesh>
    );
  }

  return (
    <group position={[0, 0, 2]}>
      {filteredBooks.map((book, index) => (
        <Book
          key={book.id}
          book={book}
          index={index}
          isSelected={selectedBookId === book.id}
          onClick={() => handleSelectBook(book.id)}
          position={positions[index]}
        />
      ))}
    </group>
  );
}
