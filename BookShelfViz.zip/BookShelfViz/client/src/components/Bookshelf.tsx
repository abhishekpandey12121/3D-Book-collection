import { useRef } from "react";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";

interface BookshelfProps {
  position: [number, number, number];
  rotation?: [number, number, number];
  width: number;
  height: number;
  depth: number;
}

export default function Bookshelf({ 
  position, 
  rotation = [0, 0, 0],
  width = 10, 
  height = 3, 
  depth = 1 
}: BookshelfProps) {
  const ref = useRef<THREE.Group>(null);
  
  // Load wood texture for bookshelf
  const woodTexture = useTexture("/textures/wood.jpg");
  woodTexture.wrapS = woodTexture.wrapT = THREE.RepeatWrapping;
  woodTexture.repeat.set(width/2, height/2);
  
  const numShelves = 3; // Number of horizontal shelves
  const shelfThickness = 0.15;
  const shelfSpacing = (height - shelfThickness) / numShelves;
  
  return (
    <group ref={ref} position={position} rotation={[rotation[0], rotation[1], rotation[2]]}>
      {/* Back panel */}
      <mesh position={[0, 0, -depth/2 + 0.01]} receiveShadow castShadow>
        <boxGeometry args={[width, height, 0.1]} />
        <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
      
      {/* Bottom shelf (base) */}
      <mesh position={[0, -height/2 + shelfThickness/2, 0]} receiveShadow castShadow>
        <boxGeometry args={[width, shelfThickness, depth]} />
        <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
      
      {/* Top shelf */}
      <mesh position={[0, height/2 - shelfThickness/2, 0]} receiveShadow castShadow>
        <boxGeometry args={[width, shelfThickness, depth]} />
        <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
      
      {/* Middle shelves */}
      {Array.from({ length: numShelves - 1 }).map((_, i) => (
        <mesh 
          key={i} 
          position={[0, -height/2 + shelfThickness + (i + 1) * shelfSpacing, 0]} 
          receiveShadow 
          castShadow
        >
          <boxGeometry args={[width, shelfThickness, depth]} />
          <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
        </mesh>
      ))}
      
      {/* Left side panel */}
      <mesh position={[-width/2 + 0.05, 0, 0]} receiveShadow castShadow>
        <boxGeometry args={[0.1, height, depth]} />
        <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
      
      {/* Right side panel */}
      <mesh position={[width/2 - 0.05, 0, 0]} receiveShadow castShadow>
        <boxGeometry args={[0.1, height, depth]} />
        <meshStandardMaterial map={woodTexture} color="#8B4513" roughness={0.7} metalness={0.2} />
      </mesh>
    </group>
  );
}