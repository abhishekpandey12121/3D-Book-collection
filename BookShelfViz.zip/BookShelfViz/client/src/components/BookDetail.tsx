import { useState, useEffect } from "react";
import { useBooks } from "@/lib/stores/useBooks";
import { BookType } from "@/lib/types";
import { X, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import BookReader from "./BookReader";

interface BookDetailProps {
  bookId: number;
  onClose: () => void;
}

export default function BookDetail({ bookId, onClose }: BookDetailProps) {
  const [book, setBook] = useState<BookType | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const { books, toggleFavorite } = useBooks();
  
  useEffect(() => {
    const selectedBook = books.find(b => b.id === bookId);
    setBook(selectedBook || null);
    
    // Animation delay for entrance
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 50);
    
    return () => clearTimeout(timer);
  }, [bookId, books]);
  
  // Close modal with animation
  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300); // Wait for exit animation
  };
  
  // Open book reader
  const handleReadBook = () => {
    if (book) {
      setIsReading(true);
    }
  };
  
  if (!book) return null;
  
  // Show book reader if in reading mode
  if (isReading && book) {
    return <BookReader book={book} onClose={() => setIsReading(false)} />;
  }
  
  return (
    <div 
      className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
      onClick={handleClose}
    >
      <div 
        className={cn(
          "bg-gray-900 rounded-lg shadow-xl max-w-2xl w-full overflow-hidden transform transition-all duration-300",
          isVisible ? "scale-100 opacity-100" : "scale-95 opacity-0"
        )}
        onClick={e => e.stopPropagation()}
      >
        <div className="relative">
          {/* Header with genre badge */}
          <div className="p-6 pb-0 flex justify-between items-start">
            <div>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                {book.genre}
              </span>
              <h2 className="text-2xl font-bold text-white mt-2">{book.title}</h2>
              <p className="text-gray-300">by {book.author}</p>
            </div>
            
            <button
              className="text-gray-400 hover:text-white transition-colors"
              onClick={handleClose}
            >
              <X size={24} />
            </button>
          </div>
          
          {/* Book content */}
          <div className="p-6">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Book cover simulation */}
              <div className="w-full md:w-1/3 aspect-[2/3] bg-gradient-to-br from-gray-700 to-gray-900 rounded-md flex items-center justify-center overflow-hidden">
                <div className="transform rotate-1 p-4 bg-gradient-to-br from-gray-800 to-gray-900 shadow-lg rounded w-full h-full flex items-center justify-center">
                  <h3 className="text-xl font-bold text-white text-center">{book.title}</h3>
                </div>
              </div>
              
              {/* Book details */}
              <div className="w-full md:w-2/3">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-white">Summary</h3>
                  <div className="flex gap-2">
                    <button
                      className="flex items-center gap-1 px-3 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={handleReadBook}
                    >
                      <BookOpen size={16} />
                      Read Book
                    </button>
                    <button
                      className={`flex items-center gap-1 px-3 py-1 rounded-md text-sm ${
                        book.favorite
                          ? "bg-yellow-600 hover:bg-yellow-700 text-white"
                          : "bg-gray-700 hover:bg-gray-600 text-white"
                      }`}
                      onClick={() => toggleFavorite(book.id)}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"
                          clipRule="evenodd"
                        />
                      </svg>
                      {book.favorite ? "Favorited" : "Favorite"}
                    </button>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-4">
                  {book.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium text-gray-400">Pages</h4>
                    <p className="text-white">{book.pages}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-400">Published</h4>
                    <p className="text-white">{book.publishYear}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-400">Language</h4>
                    <p className="text-white">{book.language}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-400">ISBN</h4>
                    <p className="text-white">{book.isbn}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
