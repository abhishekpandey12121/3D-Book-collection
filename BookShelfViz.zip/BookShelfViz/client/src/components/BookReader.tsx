import { useState, useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { BookType } from "@/lib/types";
import { cn } from "@/lib/utils";

interface BookReaderProps {
  book: BookType;
  onClose: () => void;
}

export default function BookReader({ book, onClose }: BookReaderProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [isVisible, setIsVisible] = useState(false);
  const [bookContent, setBookContent] = useState<string[]>([]);
  const totalPages = bookContent.length;
  
  // Generate book content based on the book's description
  useEffect(() => {
    // Simple algorithm to generate fake content based on the description
    const generateBookContent = () => {
      const content: string[] = [];
      
      // Title page
      content.push(`
        <div class="flex flex-col items-center justify-center h-full">
          <h1 class="text-3xl font-bold mb-6">${book.title}</h1>
          <h2 class="text-xl italic mb-12">by ${book.author}</h2>
          <p class="text-sm">Published ${book.publishYear}</p>
          <p class="text-sm">${book.genre}</p>
          <p class="text-sm mt-8">Total pages: ${book.pages}</p>
        </div>
      `);
      
      // Table of contents
      content.push(`
        <div class="flex flex-col h-full py-10">
          <h2 class="text-2xl font-bold mb-8 text-center">Table of Contents</h2>
          <ol class="list-decimal pl-12 space-y-4">
            <li>Chapter 1: Introduction</li>
            <li>Chapter 2: The Beginning</li>
            <li>Chapter 3: The Journey</li>
            <li>Chapter 4: Challenges</li>
            <li>Chapter 5: Revelations</li>
            <li>Chapter 6: The Turning Point</li>
            <li>Chapter 7: Resolution</li>
            <li>Chapter 8: Epilogue</li>
          </ol>
        </div>
      `);
      
      // Introduction and description
      content.push(`
        <div class="flex flex-col h-full py-10">
          <h2 class="text-2xl font-bold mb-6 text-center">Chapter 1: Introduction</h2>
          <p class="mb-4 leading-relaxed">${book.description}</p>
          <p class="mb-4 leading-relaxed">The story begins with our characters exploring the world around them, filled with wonder and excitement.</p>
        </div>
      `);
      
      // Generate chapters based on book length (more pages for longer books)
      const chaptersToGenerate = Math.max(5, Math.min(20, Math.floor(book.pages / 20)));
      
      for (let i = 2; i <= chaptersToGenerate; i++) {
        const chapterTitle = i === chaptersToGenerate ? "Epilogue" : `Chapter ${i}: ${getChapterTitle(i)}`;
        
        content.push(`
          <div class="flex flex-col h-full py-10">
            <h2 class="text-2xl font-bold mb-6 text-center">${chapterTitle}</h2>
            <p class="mb-4 leading-relaxed">${generateParagraph(book.genre, i)}</p>
            <p class="mb-4 leading-relaxed">${generateParagraph(book.genre, i + 100)}</p>
            ${i % 3 === 0 ? `<p class="mb-4 leading-relaxed">${generateParagraph(book.genre, i + 200)}</p>` : ''}
          </div>
        `);
      }
      
      return content;
    };
    
    setBookContent(generateBookContent());
    
    // Animation timing
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 50);
    
    return () => clearTimeout(timer);
  }, [book]);
  
  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };
  
  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  
  // Handle ESC key to close the reader
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        handleClose();
      } else if (e.key === "ArrowRight") {
        nextPage();
      } else if (e.key === "ArrowLeft") {
        prevPage();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPage, totalPages]);
  
  // Close reader with animation
  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };
  
  if (bookContent.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-xl p-10 text-center">
          <p className="text-xl">Loading book content...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div 
      className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
      onClick={handleClose}
    >
      <div 
        className={cn(
          "bg-white rounded-lg shadow-xl max-w-4xl w-full overflow-hidden flex flex-col transform transition-all duration-300",
          "h-[80vh] relative",
          isVisible ? "scale-100 opacity-100" : "scale-95 opacity-0"
        )}
        onClick={e => e.stopPropagation()}
      >
        {/* Book header */}
        <div className="p-4 bg-gray-100 flex justify-between items-center border-b">
          <h3 className="text-lg font-semibold truncate">{book.title}</h3>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="text-gray-500 hover:text-gray-700 transition-colors"
              onClick={handleClose}
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        
        {/* Book content */}
        <div className="flex-1 overflow-y-auto p-8 bg-[#f8f5e9] text-gray-800 book-page">
          <div dangerouslySetInnerHTML={{ __html: bookContent[currentPage - 1] }} />
        </div>
        
        {/* Navigation controls */}
        <div className="p-4 bg-gray-100 border-t flex justify-between items-center">
          <button
            className={cn(
              "px-4 py-2 flex items-center gap-1 rounded",
              currentPage > 1 
                ? "bg-blue-600 hover:bg-blue-700 text-white" 
                : "bg-gray-200 text-gray-400 cursor-not-allowed"
            )}
            onClick={prevPage}
            disabled={currentPage <= 1}
          >
            <ChevronLeft size={16} />
            Previous
          </button>
          
          <div className="text-sm text-gray-600">
            {currentPage} / {totalPages}
          </div>
          
          <button
            className={cn(
              "px-4 py-2 flex items-center gap-1 rounded",
              currentPage < totalPages 
                ? "bg-blue-600 hover:bg-blue-700 text-white" 
                : "bg-gray-200 text-gray-400 cursor-not-allowed"
            )}
            onClick={nextPage}
            disabled={currentPage >= totalPages}
          >
            Next
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

// Helper functions to generate text content
function getChapterTitle(chapterNum: number): string {
  const titles = [
    "The Beginning",
    "A New Journey",
    "Unexpected Encounters",
    "Revelations",
    "The Challenge",
    "A Turn of Events",
    "Hidden Truths",
    "The Confrontation",
    "Finding the Way",
    "Resolutions",
    "Moving Forward",
    "The Final Decision",
    "A New Hope",
    "The Last Stand",
    "Reunions",
    "The Discovery",
    "All is Revealed",
    "The End of the Journey",
    "Epilogue"
  ];
  
  return titles[chapterNum % titles.length];
}

function generateParagraph(genre: string, seed: number): string {
  const paragraphs: Record<string, string[]> = {
    "Sci-Fi": [
      "The spacecraft hovered silently above the alien landscape. The twin moons cast an eerie blue glow across the crystalline surface below. Captain Mercer checked the oxygen levels one more time before signaling to the crew.",
      "The neural implant hummed as it synchronized with the central AI. Data flowed through the connection, filling the user's mind with information about the surrounding environment that would otherwise be invisible to human senses.",
      "The colony on Proxima Centauri B had thrived for three generations, but the anomaly in the star's radiation output threatened everything they had built. Scientists worked around the clock to find a solution before evacuation became their only option.",
      "The time machine was smaller than expected, barely large enough for one person. Its polished chrome surface reflected the laboratory lights, giving it an almost magical appearance. Dr. Chen hesitated before entering the coordinates.",
      "The alien artifact responded to human touch in unexpected ways. Patterns of light danced across its surface, forming symbols that seemed just on the edge of comprehension. The linguistics team had been studying it for months without a breakthrough."
    ],
    "Fantasy": [
      "The dragon's scales gleamed in the sunlight as it soared above the mountain range. From the castle towers, the sentries tracked its movement with a mixture of awe and trepidation. The king had been warned of its coming.",
      "The ancient spellbook lay open on the wizard's desk, its pages yellowed with age. Runes glowed faintly in the dim light of the study, responding to the magical energies that permeated the tower.",
      "The elven forest was silent save for the gentle rustling of leaves. Moonlight filtered through the dense canopy, illuminating the path that few humans had ever walked. The scout moved forward cautiously, aware of the eyes watching from the shadows.",
      "The sword had been buried in the stone for a thousand years, waiting for the one true heir to the throne. Many had tried to claim it, their failed attempts only adding to the legend that surrounded the ancient weapon.",
      "Magic flowed through the land like rivers of invisible power. Some individuals were born with the ability to sense these currents, and fewer still could manipulate them to their will. The academy existed to find these rare talents and train them."
    ],
    "Thriller": [
      "The detective studied the crime scene with practiced eyes. Nothing seemed out of place, and that was precisely what bothered him. It was too perfect, too clean. Someone had gone to great lengths to remove any trace of their presence.",
      "The coded message had arrived at midnight, exactly as predicted. Now the race was on to decipher it before the deadline expired. Lives hung in the balance, and the clock was ticking relentlessly forward.",
      "The safe house had been compromised. She gathered only the essentials, knowing that staying even a minute longer than necessary could be fatal. The new identity package was hidden under the floorboard in the closet.",
      "He recognized the tail two blocks back, a professional by the way they maintained distance while never losing sight of their target. The question was whether to confront them now or lead them into the trap that had been prepared.",
      "The classified documents revealed a conspiracy that reached the highest levels of government. If this information became public, it would trigger a constitutional crisis unlike anything the country had seen before."
    ],
    "Fiction": [
      "The small town had changed little in the decades since they had left. The same shops lined the main street, though some names had changed. The diner on the corner, where they had spent countless hours as teenagers, still had the same neon sign.",
      "The letter arrived on a Tuesday, bringing news that would alter the course of their carefully planned life. Sometimes the universe has a way of reminding you that no matter how carefully you arrange things, randomness will always find a way in.",
      "Family gatherings had always been complicated, but this year's holiday promised to be especially tense. Old grievances simmered beneath polite conversation, waiting for the inevitable moment when someone would say too much after one glass too many.",
      "The painting captured more than just the physical likeness of its subject; somehow, the artist had managed to convey the essence of the person, a glimpse into their soul that was almost uncomfortable in its intimacy.",
      "The journey across the country had been impulsive, a break from routine that was long overdue. As the miles accumulated behind them, they felt the weight of expectations and obligations diminishing, replaced by a growing sense of possibility."
    ],
    "Romance": [
      "Their eyes met across the crowded room, and for a moment, everything else faded into the background. The music, the conversation, the very air seemed to still as an unspoken connection formed between two strangers.",
      "The misunderstanding that had kept them apart for years now seemed trivial in retrospect. Pride had prevented either from making the first move toward reconciliation, but time had a way of shifting perspectives.",
      "The love letters, tied with faded ribbon, had remained hidden in the attic for generations. As she carefully unfolded the delicate paper, the story of a passionate romance began to reveal itself through elegant handwriting and heartfelt words.",
      "Their relationship had developed slowly, friendship gradually deepening into something more. Neither had been looking for love, which perhaps explained why it had caught them both by surprise when they finally recognized what had been building between them.",
      "The promise they made under starlight seemed unbreakable at the time. Youth and optimism had made anything seem possible. Now, decades later, they found themselves back in the same spot, older and wiser but still holding onto that moment."
    ],
    "Historical Fiction": [
      "The ancient city walls had witnessed centuries of human drama, from coronations to invasions, triumphs to tragedies. Now they stood as silent sentinels as yet another chapter in history unfolded in the streets below.",
      "War had transformed the once-peaceful countryside. Where fields of wheat had swayed in the breeze, artillery now scarred the earth. Families that had farmed the land for generations were now refugees, carrying what little they could save.",
      "The royal court was a place of elegant danger, where words could be as deadly as any sword. Alliances shifted like sand dunes in the desert, and those who couldn't adapt quickly found themselves without the protection needed to survive.",
      "The new world offered opportunities impossible in the class-bound society they had left behind. Here, a person might remake themselves entirely, though the cost of such freedom was high in other ways. Loneliness and hardship tested the resolve of even the most determined settlers.",
      "Revolution was in the air, whispered in taverns and debated in universities. Ideas spread like wildfire among a population tired of oppression. What had started as intellectual discussion was rapidly transforming into action, and soon there would be no turning back."
    ]
  };
  
  // Default to Fiction if genre not found
  const genreParagraphs = paragraphs[genre] || paragraphs["Fiction"];
  return genreParagraphs[seed % genreParagraphs.length];
}