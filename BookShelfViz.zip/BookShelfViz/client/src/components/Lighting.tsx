import { useRef } from "react";
import { SpotLight, useHelper } from "@react-three/drei";
import * as THREE from "three";

export default function Lighting() {
  const spotLightRef = useRef<THREE.SpotLight>(null);
  const directionalLightRef = useRef<THREE.DirectionalLight>(null);
  
  // Uncomment for debugging lighting
  // useHelper(spotLightRef, THREE.SpotLightHelper, "white");
  // useHelper(directionalLightRef, THREE.DirectionalLightHelper, 1, "red");

  return (
    <>
      {/* Ambient light for overall scene brightness */}
      <ambientLight intensity={0.4} />
      
      {/* Main directional light with shadows */}
      <directionalLight
        ref={directionalLightRef}
        position={[5, 5, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-far={50}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />
      
      {/* Spotlight for dramatic lighting on books */}
      <SpotLight
        ref={spotLightRef}
        position={[3, 5, 2]}
        angle={0.6}
        penumbra={0.5}
        intensity={0.8}
        castShadow
        distance={10}
        attenuation={5}
        anglePower={5}
        color="#ffffff"
      />
      
      {/* Fill light from opposite direction */}
      <directionalLight position={[-5, 3, -5]} intensity={0.3} />
      
      {/* Ground plane for shadows */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]} receiveShadow>
        <planeGeometry args={[100, 100]} />
        <shadowMaterial transparent opacity={0.4} />
      </mesh>
    </>
  );
}
