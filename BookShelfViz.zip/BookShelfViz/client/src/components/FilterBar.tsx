import { useState } from "react";
import { useBooks } from "@/lib/stores/useBooks";
import GenreFilter from "./GenreFilter";
import { BookSort } from "@/lib/types";

export default function FilterBar() {
  const { 
    setGenreFilter, 
    toggleShowFavorites, 
    showFavorites, 
    sort,
    setSort,
    searchQuery,
    setSearchQuery
  } = useBooks();
  
  const handleSortChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSort(event.target.value as BookSort);
  };

  return (
    <div className="container mx-auto p-3">
      <div className="flex flex-col md:flex-row gap-3 items-center">
        <div className="w-full md:w-auto flex-1">
          <input
            type="text"
            placeholder="Search books..."
            className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="w-full md:w-auto">
          <GenreFilter onChange={setGenreFilter} />
        </div>
        
        <div className="w-full md:w-auto">
          <select
            className="px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={sort}
            onChange={handleSortChange}
          >
            <option value="title">Sort by Title</option>
            <option value="author">Sort by Author</option>
            <option value="recent">Sort by Recently Added</option>
          </select>
        </div>
        
        <button
          className={`px-4 py-2 rounded-md ${
            showFavorites
              ? "bg-yellow-600 hover:bg-yellow-700 text-white"
              : "bg-gray-700 hover:bg-gray-600 text-white"
          }`}
          onClick={() => toggleShowFavorites()}
        >
          {showFavorites ? "All Books" : "Favorites Only"}
        </button>
      </div>
    </div>
  );
}
