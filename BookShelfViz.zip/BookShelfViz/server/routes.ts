import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function registerRoutes(app: Express): Promise<Server> {
  // Get books data
  const booksDataPath = path.resolve(__dirname, "data", "books.json");
  console.log("Books data path:", booksDataPath);
  
  // Books API endpoint
  app.get("/api/books", (req, res) => {
    try {
      console.log("Attempting to read books data from:", booksDataPath);
      console.log("File exists:", fs.existsSync(booksDataPath));
      const booksData = JSON.parse(fs.readFileSync(booksDataPath, "utf-8"));
      res.json(booksData);
    } catch (error) {
      console.error("Error reading books data:", error);
      res.status(500).json({ message: "Failed to load books data" });
    }
  });
  
  // Get book by ID
  app.get("/api/books/:id", (req, res) => {
    try {
      const bookId = parseInt(req.params.id);
      console.log("Attempting to read book with ID:", bookId);
      const booksData = JSON.parse(fs.readFileSync(booksDataPath, "utf-8"));
      const book = booksData.find((b: any) => b.id === bookId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      
      res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
